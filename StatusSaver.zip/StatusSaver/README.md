# Status Saver (Android 11+, built for Android 14/15)

Kotlin + Jetpack Compose. No storage permission: statuses are read through the
Storage Access Framework (SAF) and copies are written with MediaStore.

## Features
- Multi-account WhatsApp: you grant the WhatsApp folder once; the app scans it for every
  ".Statuses" folder (main and accounts/<id>/...) and shows one tab per account. Rename them in Settings.
- WhatsApp and WhatsApp Business.
- Grid, multi-select, swipe viewer (images + video), save, share, delete.
- Auto-save of NEW statuses (WorkManager, about every 15 min).
- English + French (follows the phone language; per-app language on Android 13+).
- Theme: System / Light / Dark.

## Build
1. Open the folder in Android Studio (Ladybug or newer, JDK 17) and let Gradle sync.
2. Run on a phone with WhatsApp. View a few statuses first.
3. Statuses tab -> "Connect WhatsApp" -> "Use this folder" -> "Allow".

## Before publishing
- Change `applicationId` / `namespace` in `app/build.gradle.kts` and move the package.
- Replace the launcher icon, add a privacy policy.
- Never add MANAGE_EXTERNAL_STORAGE: Google Play rejects it for this use case.
