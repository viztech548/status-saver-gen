package com.example.statussaver.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.statussaver.R

/** Put your real links here. Leave a value empty to hide that button. */
object DonationLinks {
    const val KOFI_URL = ""   // e.g. "https://ko-fi.com/yourname"
    const val WAVE_URL = ""   // e.g. your Wave payment link
}

private fun openLink(context: Context, url: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: ActivityNotFoundException) {
    }
}

@Composable
fun DonateScreen() {
    val context = LocalContext.current
    val links = listOf(
        R.string.donate_kofi to DonationLinks.KOFI_URL,
        R.string.donate_wave to DonationLinks.WAVE_URL,
    ).filter { it.second.isNotBlank() }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
    ) {
        Icon(Icons.Filled.Favorite, null, Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary)
        Text(stringResource(R.string.donate_title), style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Text(stringResource(R.string.donate_body), style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
        if (links.isEmpty()) {
            Text(stringResource(R.string.donate_not_ready), color = MaterialTheme.colorScheme.error)
        }
        links.forEach { (label, url) ->
            Button(onClick = { openLink(context, url) }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(label))
            }
        }
        Text(
            stringResource(R.string.donate_note),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}
