package com.example.statussaver.data

import android.net.Uri

/**
 * One ".Statuses" folder. A WhatsApp with two accounts has one feed per account
 * (found under .../WhatsApp/accounts/<id>/...), plus possibly a main one.
 */
data class StatusFeed(
    val key: String,
    val app: WaApp,
    val treeUri: Uri,
    val docId: String,
    val accountId: String?,
) {
    val defaultLabel: String
        get() = app.label + (accountId?.let { " · $it" } ?: "")
}
