package com.example.statussaver.data

import android.content.ContentResolver
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

/** Runs [block], returning null on any failure except cancellation. */
internal suspend fun <T> attempt(block: suspend () -> T): T? =
    try { block() } catch (e: CancellationException) { throw e } catch (e: Exception) { null }

class StatusRepository(context: Context, val prefs: AppPrefs = AppPrefs(context)) {

    private val resolver: ContentResolver = context.applicationContext.contentResolver
    private val feedCache = ConcurrentHashMap<WaApp, List<StatusFeed>>()

    // ---------------------------------------------------------------- access

    /** True only if a folder is stored AND the system still holds the grant. */
    fun hasAccess(app: WaApp): Boolean {
        val saved = prefs.treeUri(app) ?: return false
        return resolver.persistedUriPermissions.any { it.uri == saved && it.isReadPermission }
    }

    /** Accepts the WhatsApp folder, its parent, or a .Statuses folder; rejects unrelated folders. */
    fun isPlausibleFolder(app: WaApp, treeUri: Uri): Boolean {
        val id = runCatching { DocumentsContract.getTreeDocumentId(treeUri) }.getOrNull()?.lowercase() ?: return false
        val business = id.contains("w4b") || id.contains("business")
        return id.contains("whatsapp") && business == (app == WaApp.BUSINESS)
    }

    fun storeTree(app: WaApp, uri: Uri) {
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        resolver.takePersistableUriPermission(uri, flags)
        prefs.treeUri(app)?.takeIf { it != uri }?.let {
            runCatching { resolver.releasePersistableUriPermission(it, flags) }
        }
        prefs.setTreeUri(app, uri)
        feedCache.remove(app)
    }

    // ------------------------------------------------------------- discovery

    /**
     * Finds every ".Statuses" folder under the granted folder, so a WhatsApp with two
     * accounts (accounts/1003, accounts/1008 ...) shows one feed per account.
     */
    suspend fun discoverFeeds(app: WaApp, force: Boolean = false): List<StatusFeed> =
        withContext(Dispatchers.IO) {
            if (!force) feedCache[app]?.takeIf { it.isNotEmpty() }?.let { return@withContext it }
            val tree = prefs.treeUri(app) ?: return@withContext emptyList()
            scan(app, tree).also { feedCache[app] = it }
        }

    private fun scan(app: WaApp, tree: Uri): List<StatusFeed> {
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        if (rootId.endsWith(STATUSES_DIR)) return listOf(feedOf(app, tree, rootId))

        val found = mutableListOf<StatusFeed>()
        val queue = ArrayDeque<Pair<String, Int>>()
        queue.add(rootId to 0)
        while (queue.isNotEmpty()) {
            val (parent, depth) = queue.removeFirst()
            val subdirs = mutableListOf<String>()
            var hasStatuses = false
            queryChildren(tree, parent) { id, name, mime, _, _ ->
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    if (name == STATUSES_DIR) {
                        found.add(feedOf(app, tree, id))
                        hasStatuses = true
                    } else if (!name.startsWith(".") && !SKIP_DIRS.matches(name)) {
                        subdirs.add(id)
                    }
                }
            }
            // Once we are in the Media folder of an account, no need to open its sibling media folders.
            if (!hasStatuses && depth + 1 < MAX_DEPTH) subdirs.forEach { queue.add(it to depth + 1) }
        }
        return found.sortedBy { it.docId }
    }

    private fun feedOf(app: WaApp, tree: Uri, docId: String) = StatusFeed(
        key = "${app.name}|$docId",
        app = app,
        treeUri = tree,
        docId = docId,
        accountId = ACCOUNT_REGEX.find(docId)?.groupValues?.get(1),
    )

    private inline fun queryChildren(
        tree: Uri,
        parentDocId: String,
        block: (id: String, name: String, mime: String, modified: Long, size: Long) -> Unit,
    ) {
        val uri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentDocId)
        resolver.query(uri, CHILD_PROJECTION, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: continue
                block(id, name, c.getString(2) ?: "", c.getLong(3), c.getLong(4))
            }
        }
    }

    // --------------------------------------------------------------- statuses

    /** Images/videos of one feed, newest first. Throws if the grant is gone. */
    suspend fun listStatuses(feed: StatusFeed): List<StatusItem> = withContext(Dispatchers.IO) {
        val out = mutableListOf<StatusItem>()
        queryChildren(feed.treeUri, feed.docId) { id, name, mime, modified, size ->
            if (mime.startsWith("image/") || mime.startsWith("video/")) { // skips .nomedia
                out.add(StatusItem(DocumentsContract.buildDocumentUriUsingTree(feed.treeUri, id), name, mime, modified, size))
            }
        }
        out.sortedByDescending { it.modified }
    }

    // ------------------------------------------------------------------ saved

    /** Files this app saved. Readable without any permission (we own them). */
    suspend fun listSaved(): List<StatusItem> = withContext(Dispatchers.IO) {
        val base = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.DATE_MODIFIED,
            MediaStore.MediaColumns.SIZE,
        )
        val rel = MediaStore.MediaColumns.RELATIVE_PATH
        val args = arrayOf("$IMAGE_DIR/$APP_FOLDER/%", "$VIDEO_DIR/$APP_FOLDER/%")
        val out = mutableListOf<StatusItem>()
        resolver.query(base, projection, "$rel LIKE ? OR $rel LIKE ?", args, "${MediaStore.MediaColumns.DATE_MODIFIED} DESC")
            ?.use { c ->
                while (c.moveToNext()) {
                    out.add(
                        StatusItem(
                            uri = ContentUris.withAppendedId(base, c.getLong(0)),
                            name = c.getString(1) ?: continue,
                            mimeType = c.getString(2) ?: continue,
                            modified = c.getLong(3) * 1000L,
                            sizeBytes = c.getLong(4),
                        )
                    )
                }
            }
        out
    }

    /** Copies a status to Pictures/StatusSaver or Movies/StatusSaver. Idempotent by file name. */
    suspend fun save(item: StatusItem): Uri = withContext(Dispatchers.IO) {
        saveLock.withLock {
            listSaved().firstOrNull { it.name == item.name }?.uri ?: copyToGallery(item)
        }
    }

    private fun copyToGallery(item: StatusItem): Uri {
        val video = item.isVideo
        val collection = if (video) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, item.name)
            put(MediaStore.MediaColumns.MIME_TYPE, item.mimeType)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "${if (video) VIDEO_DIR else IMAGE_DIR}/$APP_FOLDER")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val dest = resolver.insert(collection, values) ?: throw IOException("Could not create file")
        try {
            val input = resolver.openInputStream(item.uri) ?: throw IOException("Cannot read status")
            val output = resolver.openOutputStream(dest) ?: throw IOException("Cannot write file")
            input.use { i -> output.use { o -> i.copyTo(o) } }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(dest, values, null, null)
        } catch (e: Exception) {
            resolver.delete(dest, null, null)
            throw e
        }
        return dest
    }

    suspend fun deleteSaved(item: StatusItem) = withContext(Dispatchers.IO) {
        resolver.delete(item.uri, null, null)
    }

    private companion object {
        const val APP_FOLDER = "548 Status"
        const val STATUSES_DIR = ".Statuses"
        const val MAX_DEPTH = 8
        val IMAGE_DIR: String = Environment.DIRECTORY_PICTURES
        val VIDEO_DIR: String = Environment.DIRECTORY_MOVIES
        val ACCOUNT_REGEX = Regex("accounts/([^/]+)/")
        // Big media folders and backups never contain .Statuses; skipping them keeps the scan fast.
        val SKIP_DIRS = Regex(
            "^(Backups|Databases|\\.Shared|\\.Thumbs|WhatsApp (Business )?" +
                "(Images|Video|Audio|Documents|Animated Gifs|Voice Notes|Stickers|Profile Photos|Video Notes|Sticker Packs|Bug Report))$"
        )
        val CHILD_PROJECTION = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
            DocumentsContract.Document.COLUMN_SIZE,
        )
        val saveLock = Mutex() // process-wide: manual saves and auto-save never race
    }
}
