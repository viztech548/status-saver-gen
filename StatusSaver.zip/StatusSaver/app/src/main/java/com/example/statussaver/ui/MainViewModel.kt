package com.example.statussaver.ui

import android.app.Application
import android.net.Uri
import androidx.annotation.StringRes
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.statussaver.R
import com.example.statussaver.data.AppPrefs
import com.example.statussaver.data.AutoSaveScheduler
import com.example.statussaver.data.AutoSaver
import com.example.statussaver.data.StatusFeed
import com.example.statussaver.data.StatusItem
import com.example.statussaver.data.StatusRepository
import com.example.statussaver.data.ThemeMode
import com.example.statussaver.data.WaApp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class UiState(
    val feeds: List<StatusFeed> = emptyList(),
    val selectedFeedKey: String? = null,
    val access: Map<WaApp, Boolean> = emptyMap(),
    val statuses: Map<String, List<StatusItem>> = emptyMap(),
    val nicknames: Map<String, String> = emptyMap(),
    val saved: List<StatusItem> = emptyList(),
    val savedNames: Set<String> = emptySet(),
    val refreshing: Boolean = false,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val autoSave: Boolean = false,
    val askBusiness: Boolean = false,
) {
    val currentFeed: StatusFeed? get() = feeds.firstOrNull { it.key == selectedFeedKey }
}

fun feedLabel(feed: StatusFeed, nicknames: Map<String, String>): String =
    nicknames[feed.key] ?: feed.defaultLabel

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = AppPrefs(app)
    private val repo = StatusRepository(app, prefs)
    private val autoSaver = AutoSaver(repo)

    private val _state = MutableStateFlow(
        UiState(
            access = WaApp.entries.associateWith { repo.hasAccess(it) },
            themeMode = prefs.themeMode,
            autoSave = prefs.autoSave,
        )
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages = _messages.receiveAsFlow()

    fun selectFeed(key: String) = _state.update { it.copy(selectedFeedKey = key) }

    /** force = true rescans for new accounts (pull-to-refresh); otherwise folders are cached. */
    fun refresh(force: Boolean) {
        viewModelScope.launch { load(force) }
    }

    private suspend fun load(force: Boolean) {
        _state.update { it.copy(refreshing = true) }

        val feeds = mutableListOf<StatusFeed>()
        val statuses = mutableMapOf<String, List<StatusItem>>()
        val access = mutableMapOf<WaApp, Boolean>()
        for (app in WaApp.entries) {
            val ok = repo.hasAccess(app)
            access[app] = ok
            if (!ok) continue
            try {
                for (feed in repo.discoverFeeds(app, force)) {
                    feeds.add(feed)
                    statuses[feed.key] = try {
                        repo.listStatuses(feed)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (_: Exception) {
                        emptyList()
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                access[app] = false // grant revoked or folder removed: ask again
            }
        }
        val nicknames = feeds.mapNotNull { f -> prefs.nickname(f.key)?.let { f.key to it } }.toMap()

        _state.update {
            it.copy(
                feeds = feeds,
                statuses = statuses,
                access = access,
                nicknames = nicknames,
                selectedFeedKey = it.selectedFeedKey?.takeIf { k -> feeds.any { f -> f.key == k } }
                    ?: feeds.firstOrNull()?.key,
            )
        }
        loadSaved()
        _state.update { it.copy(refreshing = false) }

        if (prefs.autoSave && autoSaver.run() > 0) loadSaved()
    }

    fun onFolderPicked(app: WaApp, uri: Uri) {
        if (!repo.isPlausibleFolder(app, uri)) {
            send(R.string.msg_wrong_folder)
            return
        }
        repo.storeTree(app, uri)
        viewModelScope.launch {
            load(force = true)
            val s = _state.value
            if (s.feeds.none { it.app == app }) {
                send(R.string.msg_no_status_folder)
            } else if (app == WaApp.WHATSAPP && s.access[WaApp.BUSINESS] != true &&
                !prefs.businessPromptDone && isInstalled("com.whatsapp.w4b")
            ) {
                _state.update { it.copy(askBusiness = true) } // offer to connect Business right away
            }
        }
    }

    fun answerBusinessPrompt() {
        prefs.businessPromptDone = true
        _state.update { it.copy(askBusiness = false) }
    }

    private fun isInstalled(pkg: String): Boolean = try {
        @Suppress("DEPRECATION")
        getApplication<Application>().packageManager.getPackageInfo(pkg, 0)
        true
    } catch (_: Exception) {
        false
    }

    fun save(items: List<StatusItem>) {
        viewModelScope.launch {
            var ok = 0
            for (item in items) {
                try { repo.save(item); ok++ } catch (e: CancellationException) { throw e } catch (_: Exception) {}
            }
            loadSaved()
            if (ok == items.size) send(R.string.msg_saved, ok) else send(R.string.msg_saved_partial, ok, items.size)
        }
    }

    /** Sharing goes through our own saved copy, so the receiving app gets a valid MediaStore Uri. */
    fun share(item: StatusItem, onReady: (StatusItem) -> Unit) {
        viewModelScope.launch {
            try {
                val uri = repo.save(item)
                loadSaved()
                onReady(item.copy(uri = uri))
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                send(R.string.msg_share_failed)
            }
        }
    }

    fun delete(items: List<StatusItem>) {
        viewModelScope.launch {
            items.forEach { runCatching { repo.deleteSaved(it) } }
            loadSaved()
            send(R.string.msg_deleted, items.size)
        }
    }

    // ---------------------------------------------------------------- settings

    fun setTheme(mode: ThemeMode) {
        prefs.themeMode = mode
        _state.update { it.copy(themeMode = mode) }
    }

    fun setAutoSave(enabled: Boolean) {
        viewModelScope.launch {
            if (enabled) autoSaver.markAllSeen()
            prefs.autoSave = enabled
            AutoSaveScheduler.apply(getApplication(), enabled)
            _state.update { it.copy(autoSave = enabled) }
        }
    }

    fun rename(feedKey: String, name: String) {
        prefs.setNickname(feedKey, name)
        _state.update { s ->
            val n = name.trim()
            s.copy(nicknames = if (n.isEmpty()) s.nicknames - feedKey else s.nicknames + (feedKey to n))
        }
    }

    // ---------------------------------------------------------------- internals

    private suspend fun loadSaved() {
        val saved = repo.listSaved()
        _state.update { it.copy(saved = saved, savedNames = saved.mapTo(HashSet()) { s -> s.name }) }
    }

    private fun send(@StringRes id: Int, vararg args: Any) {
        _messages.trySend(getApplication<Application>().getString(id, *args))
    }
}
