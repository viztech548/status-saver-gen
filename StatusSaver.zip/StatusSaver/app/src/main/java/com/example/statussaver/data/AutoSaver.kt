package com.example.statussaver.data

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.TimeUnit

/** Saves statuses that appeared since auto-save was switched on. */
class AutoSaver(private val repo: StatusRepository) {
    private val prefs get() = repo.prefs

    /** Marks every current status as seen so only FUTURE statuses get saved. */
    suspend fun markAllSeen() = runLock.withLock {
        val seen = LinkedHashSet(prefs.autoSaved)
        forEachItem { seen.add(it.name) }
        prefs.autoSaved = seen
    }

    /** Returns how many new statuses were saved. */
    suspend fun run(): Int = runLock.withLock {
        if (!prefs.autoSave) return@withLock 0
        val seen = LinkedHashSet(prefs.autoSaved)
        var count = 0
        forEachItem { item ->
            if (item.name !in seen && attempt { repo.save(item) } != null) {
                seen.add(item.name)
                count++
            }
        }
        prefs.autoSaved = seen
        count
    }

    private suspend fun forEachItem(block: suspend (StatusItem) -> Unit) {
        for (app in WaApp.entries) {
            if (!repo.hasAccess(app)) continue
            val feeds = attempt { repo.discoverFeeds(app) } ?: continue
            for (feed in feeds) {
                val items = attempt { repo.listStatuses(feed) } ?: continue
                for (item in items) block(item)
            }
        }
    }

    private companion object { val runLock = Mutex() }
}

class AutoSaveWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val repo = StatusRepository(applicationContext)
        AutoSaver(repo).run()                       // optional: save new statuses to the gallery
        RewindManager(applicationContext, repo).run() // keep copies for 7 days
        return Result.success()
    }
}

object AutoSaveScheduler {
    private const val NAME = "auto_save"

    /** One background job serves both features: it runs if either is switched on. */
    fun sync(context: Context, prefs: AppPrefs) = apply(context, prefs.autoSave || prefs.rewindEnabled)

    fun apply(context: Context, enabled: Boolean) {
        val wm = WorkManager.getInstance(context)
        if (enabled) {
            wm.enqueueUniquePeriodicWork(
                NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                PeriodicWorkRequestBuilder<AutoSaveWorker>(15, TimeUnit.MINUTES).build(),
            )
        } else {
            wm.cancelUniqueWork(NAME)
        }
    }
}
