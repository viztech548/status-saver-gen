package com.example.statussaver

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder

class StatusSaverApplication : Application(), ImageLoaderFactory {
    // Video frame decoder lets Coil render thumbnails for .mp4 statuses.
    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .components { add(VideoFrameDecoder.Factory()) }
        .crossfade(true)
        .build()
}
