package com.example.statussaver

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import coil.memory.MemoryCache

class StatusSaverApplication : Application(), ImageLoaderFactory {
    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .components { add(VideoFrameDecoder.Factory()) } // thumbnails for videos
        .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.30).build() } // keeps more thumbnails ready
        .crossfade(false) // the fade-in animation costs time on every cell while scrolling
        .build()
}
