package com.example.statussaver.data

import android.content.Context
import android.net.Uri

class AppPrefs(context: Context) {
    private val p = context.applicationContext.getSharedPreferences("status_saver", Context.MODE_PRIVATE)

    fun treeUri(app: WaApp): Uri? = p.getString("tree_${app.name}", null)?.let(Uri::parse)
    fun setTreeUri(app: WaApp, uri: Uri) = p.edit().putString("tree_${app.name}", uri.toString()).apply()

    var themeMode: ThemeMode
        get() = runCatching { ThemeMode.valueOf(p.getString("theme", "") ?: "") }.getOrDefault(ThemeMode.SYSTEM)
        set(value) = p.edit().putString("theme", value.name).apply()

    var autoSave: Boolean
        get() = p.getBoolean("auto_save", false)
        set(value) = p.edit().putBoolean("auto_save", value).apply()

    fun nickname(feedKey: String): String? = p.getString("nick_$feedKey", null)
    fun setNickname(feedKey: String, name: String?) {
        p.edit().apply { if (name.isNullOrBlank()) remove("nick_$feedKey") else putString("nick_$feedKey", name.trim()) }.apply()
    }

    /** Names of statuses the auto-saver already handled (oldest first, capped). */
    var autoSaved: Set<String>
        get() = p.getString("auto_seen", "")!!.split('\n').filter { it.isNotEmpty() }.toCollection(LinkedHashSet())
        set(value) = p.edit().putString("auto_seen", value.toList().takeLast(1500).joinToString("\n")).apply()
}
