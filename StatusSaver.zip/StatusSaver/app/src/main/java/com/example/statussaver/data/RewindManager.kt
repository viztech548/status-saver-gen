package com.example.statussaver.data

import android.content.Context
import android.net.Uri
import android.webkit.MimeTypeMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

/**
 * "Rewind": copies statuses into the app's private storage and keeps them for 7 days,
 * so they can still be seen after WhatsApp deletes them (statuses live 24 hours).
 */
class RewindManager(private val context: Context, private val repo: StatusRepository) {

    private val prefs get() = repo.prefs
    private val dir: File get() = File(context.filesDir, "rewind").also { it.mkdirs() }

    /** Background job entry point: scans the connected folders itself, then copies what is new. */
    suspend fun run() {
        if (!prefs.rewindEnabled) return
        val items = mutableListOf<StatusItem>()
        for (app in WaApp.entries) {
            if (!repo.hasAccess(app)) continue
            val feeds = attempt { repo.discoverFeeds(app) } ?: continue
            for (feed in feeds) attempt { repo.listStatuses(feed) }?.let { items.addAll(it) }
        }
        capture(items)
    }

    /** Copies every status that is not already in Rewind. Returns how many were added. */
    suspend fun capture(items: List<StatusItem>): Int = withContext(Dispatchers.IO) {
        lock.withLock {
            if (!prefs.rewindEnabled) return@withLock 0
            purgeExpired()
            val ignored = prefs.rewindIgnored
            var added = 0
            for (item in items) {
                if (item.name in ignored) continue
                val safeName = item.name.replace('/', '_')
                val target = File(dir, safeName)
                if (target.exists()) continue
                val tmp = File(dir, "$safeName.part")
                val ok = try {
                    val input = context.contentResolver.openInputStream(item.uri)
                    if (input == null) {
                        false
                    } else {
                        input.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                        tmp.setLastModified(System.currentTimeMillis()) // capture time = start of the 7 days
                        tmp.renameTo(target)
                    }
                } catch (_: Exception) {
                    false
                }
                if (ok) added++ else tmp.delete()
            }
            added
        }
    }

    /** Everything still inside the 7-day window, newest first. */
    suspend fun list(): List<StatusItem> = withContext(Dispatchers.IO) {
        purgeExpired()
        dir.listFiles()
            ?.filter { it.isFile && !it.name.endsWith(".part") }
            ?.map { toItem(it) }
            ?.sortedByDescending { it.modified }
            ?: emptyList()
    }

    suspend fun delete(items: List<StatusItem>) = withContext(Dispatchers.IO) {
        lock.withLock {
            val ignored = LinkedHashSet(prefs.rewindIgnored)
            for (item in items) {
                File(dir, item.name).delete()
                ignored.add(item.name)
            }
            prefs.rewindIgnored = ignored
        }
    }

    suspend fun clearAll() = withContext(Dispatchers.IO) {
        lock.withLock {
            val ignored = LinkedHashSet(prefs.rewindIgnored)
            dir.listFiles()?.forEach { f ->
                ignored.add(f.name)
                f.delete()
            }
            prefs.rewindIgnored = ignored
        }
    }

    private fun purgeExpired() {
        val now = System.currentTimeMillis()
        dir.listFiles()?.forEach { f ->
            val limit = if (f.name.endsWith(".part")) HOUR_MS else RETENTION_MS
            if (now - f.lastModified() > limit) f.delete()
        }
    }

    private fun toItem(f: File): StatusItem {
        val ext = f.extension.lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            ?: if (ext in setOf("mp4", "3gp", "mkv", "webm", "mov")) "video/mp4" else "image/jpeg"
        return StatusItem(Uri.fromFile(f), f.name, mime, f.lastModified(), f.length())
    }

    companion object {
        const val RETENTION_MS = 7L * 24 * 60 * 60 * 1000
        private const val HOUR_MS = 60L * 60 * 1000
        private val lock = Mutex()
    }
}
