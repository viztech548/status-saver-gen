package com.example.statussaver.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.statussaver.R
import com.example.statussaver.data.WaApp

/** Shown on the Statuses tab until at least one status folder has been found. */
@Composable
fun OnboardingScreen(access: Map<WaApp, Boolean>, onConnect: (WaApp) -> Unit) {
    val anyAccess = access.values.any { it }
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
    ) {
        Icon(Icons.Filled.FolderOpen, null, Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary)
        Text(stringResource(R.string.onboarding_title), style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Text(stringResource(R.string.onboarding_body), style = MaterialTheme.typography.bodyMedium)
        Text(
            stringResource(R.string.onboarding_hint),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (anyAccess) {
            Text(stringResource(R.string.no_feeds_found), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
        }
        WaApp.entries.forEachIndexed { i, app ->
            val connected = access[app] == true
            val label = stringResource(if (connected) R.string.choose_again_app else R.string.connect_app, app.label)
            if (i == 0) {
                Button(onClick = { onConnect(app) }, modifier = Modifier.fillMaxWidth()) { Text(label) }
            } else {
                OutlinedButton(onClick = { onConnect(app) }, modifier = Modifier.fillMaxWidth()) { Text(label) }
            }
        }
        Text(
            stringResource(R.string.rights_notice),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}
