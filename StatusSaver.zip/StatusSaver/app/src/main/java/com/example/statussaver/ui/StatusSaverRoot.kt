package com.example.statussaver.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.statussaver.R
import com.example.statussaver.data.StatusItem
import com.example.statussaver.data.WaApp

enum class HomeTab(@StringRes val label: Int, val icon: ImageVector) {
    STATUSES(R.string.tab_statuses, Icons.Filled.Visibility),
    SAVED(R.string.tab_saved, Icons.Filled.Bookmarks),
    SETTINGS(R.string.tab_settings, Icons.Filled.Settings),
}

data class PreviewRequest(val items: List<StatusItem>, val index: Int, val isSavedTab: Boolean)

/** Opens the system folder picker directly on the WhatsApp folder. */
fun buildPickerIntent(app: WaApp): Intent {
    val initial = DocumentsContract.buildDocumentUri(
        "com.android.externalstorage.documents",
        app.initialDocumentId,
    )
    return Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
        putExtra(DocumentsContract.EXTRA_INITIAL_URI, initial)
        addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        )
    }
}

fun shareItem(context: Context, item: StatusItem) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = item.mimeType
        putExtra(Intent.EXTRA_STREAM, item.uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(send, null))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatusSaverRoot(vm: MainViewModel) {
    val context = LocalContext.current
    val state by vm.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    var tab by rememberSaveable { mutableStateOf(HomeTab.STATUSES) }
    var pickingApp by rememberSaveable { mutableStateOf(WaApp.WHATSAPP) }
    var selected by remember { mutableStateOf(emptySet<Uri>()) }
    var preview by remember { mutableStateOf<PreviewRequest?>(null) }

    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it) } }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refresh(force = false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        result.data?.data?.let { vm.onFolderPicked(pickingApp, it) }
    }
    fun pick(app: WaApp) {
        pickingApp = app
        picker.launch(buildPickerIntent(app))
    }

    val feedItems = state.currentFeed?.let { state.statuses[it.key] }.orEmpty()
    val items = if (tab == HomeTab.SAVED) state.saved else feedItems
    val selectedItems = items.filter { it.uri in selected }

    BackHandler(enabled = selected.isNotEmpty()) { selected = emptySet() }

    fun toggle(item: StatusItem) {
        selected = if (item.uri in selected) selected - item.uri else selected + item.uri
    }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            topBar = {
                if (selected.isNotEmpty()) {
                    TopAppBar(
                        title = { Text(stringResource(R.string.selected_count, selected.size)) },
                        navigationIcon = {
                            IconButton(onClick = { selected = emptySet() }) {
                                Icon(Icons.Filled.Close, stringResource(R.string.cd_clear_selection))
                            }
                        },
                        actions = {
                            if (tab == HomeTab.STATUSES) {
                                IconButton(onClick = { vm.save(selectedItems); selected = emptySet() }) {
                                    Icon(Icons.Filled.Download, stringResource(R.string.cd_save_selected))
                                }
                            } else {
                                IconButton(onClick = { vm.delete(selectedItems); selected = emptySet() }) {
                                    Icon(Icons.Filled.Delete, stringResource(R.string.cd_delete_selected))
                                }
                            }
                        },
                    )
                } else {
                    TopAppBar(title = { Text(stringResource(R.string.app_name)) })
                }
            },
            bottomBar = {
                NavigationBar {
                    HomeTab.entries.forEach { t ->
                        NavigationBarItem(
                            selected = tab == t,
                            onClick = { tab = t; selected = emptySet() },
                            icon = { Icon(t.icon, contentDescription = null) },
                            label = { Text(stringResource(t.label)) },
                        )
                    }
                }
            },
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                when (tab) {
                    HomeTab.STATUSES -> {
                        if (state.feeds.isEmpty()) {
                            OnboardingScreen(access = state.access, onConnect = ::pick)
                        } else {
                            val index = state.feeds.indexOfFirst { it.key == state.selectedFeedKey }.coerceAtLeast(0)
                            ScrollableTabRow(selectedTabIndex = index, edgePadding = 8.dp) {
                                state.feeds.forEach { feed ->
                                    Tab(
                                        selected = feed.key == state.selectedFeedKey,
                                        onClick = { vm.selectFeed(feed.key); selected = emptySet() },
                                        text = { Text(feedLabel(feed, state.nicknames)) },
                                    )
                                }
                            }
                            Grid(items, state, selected, stringResource(R.string.empty_statuses), vm,
                                onOpen = { i -> preview = PreviewRequest(items, i, false) },
                                onToggle = ::toggle)
                        }
                    }
                    HomeTab.SAVED -> Grid(items, state, selected, stringResource(R.string.empty_saved), vm,
                        onOpen = { i -> preview = PreviewRequest(items, i, true) },
                        onToggle = ::toggle)
                    HomeTab.SETTINGS -> SettingsScreen(
                        state = state,
                        onTheme = vm::setTheme,
                        onAutoSave = vm::setAutoSave,
                        onConnect = ::pick,
                        onRename = vm::rename,
                    )
                }
            }
        }

        preview?.let { req ->
            BackHandler { preview = null }
            PreviewScreen(
                request = req,
                savedNames = state.savedNames,
                onClose = { preview = null },
                onSave = { vm.save(listOf(it)) },
                onShare = { item -> vm.share(item) { shareItem(context, it) } },
                onDelete = { vm.delete(listOf(it)); preview = null },
            )
        }

        SnackbarHost(
            hostState = snackbar,
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 88.dp),
        )
    }
}

@Composable
private fun Grid(
    items: List<StatusItem>,
    state: UiState,
    selected: Set<Uri>,
    emptyText: String,
    vm: MainViewModel,
    onOpen: (Int) -> Unit,
    onToggle: (StatusItem) -> Unit,
) {
    MediaGrid(
        items = items,
        savedNames = state.savedNames,
        selected = selected,
        refreshing = state.refreshing,
        emptyText = emptyText,
        onRefresh = { vm.refresh(force = true) },
        onClick = { index, item -> if (selected.isNotEmpty()) onToggle(item) else onOpen(index) },
        onLongClick = onToggle,
    )
}
