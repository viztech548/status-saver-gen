package com.example.statussaver.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.SystemClock
import android.provider.DocumentsContract
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.statussaver.BuildConfig
import com.example.statussaver.R
import com.example.statussaver.data.StatusItem
import com.example.statussaver.data.WaApp
import kotlinx.coroutines.launch

enum class HomeTab(@StringRes val label: Int, val icon: ImageVector) {
    STATUSES(R.string.tab_statuses, Icons.Filled.Visibility),
    REWIND(R.string.tab_rewind, Icons.Filled.History),
    SAVED(R.string.tab_saved, Icons.Filled.Bookmarks),
    SETTINGS(R.string.tab_settings, Icons.Filled.Settings),
    DONATE(R.string.tab_donate, Icons.Filled.Favorite),
}

/** The Support tab exists only in the direct APK, never in the Google Play build. */
private val visibleTabs: List<HomeTab> =
    HomeTab.entries.filter { it != HomeTab.DONATE || BuildConfig.DONATIONS_ENABLED }

enum class PreviewSource { STATUS, REWIND, SAVED }

data class PreviewRequest(val items: List<StatusItem>, val index: Int, val source: PreviewSource)

/** Opens the system folder picker directly on the WhatsApp folder. */
fun buildPickerIntent(app: WaApp): Intent {
    val initial = DocumentsContract.buildDocumentUri(
        "com.android.externalstorage.documents",
        app.initialDocumentId,
    )
    return Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
        putExtra(DocumentsContract.EXTRA_INITIAL_URI, initial)
        addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        )
    }
}

fun shareItem(context: Context, item: StatusItem) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = item.mimeType
        putExtra(Intent.EXTRA_STREAM, item.uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(send, null))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatusSaverRoot(vm: MainViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val state by vm.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    var tab by rememberSaveable { mutableStateOf(HomeTab.STATUSES) }
    var filter by rememberSaveable { mutableStateOf(MediaFilter.ALL) }
    var pickingApp by rememberSaveable { mutableStateOf(WaApp.WHATSAPP) }
    var selected by remember { mutableStateOf(emptySet<Uri>()) }
    var preview by remember { mutableStateOf<PreviewRequest?>(null) }
    var lastBack by remember { mutableLongStateOf(0L) }
    val exitHint = stringResource(R.string.press_back_again)

    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it) } }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refresh(force = false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        result.data?.data?.let { vm.onFolderPicked(pickingApp, it) }
    }
    fun pick(app: WaApp) {
        pickingApp = app
        picker.launch(buildPickerIntent(app))
    }

    val feedIndex = state.feeds.indexOfFirst { it.key == state.selectedFeedKey }.coerceAtLeast(0)
    val feedItems = state.currentFeed?.let { state.statuses[it.key] }.orEmpty()
    val baseItems = when (tab) {
        HomeTab.SAVED -> state.saved
        HomeTab.REWIND -> state.rewind
        else -> feedItems
    }
    // "All" -> swipe moves between accounts; Images/Videos -> swipe moves between categories.
    val feedsMode = tab == HomeTab.STATUSES && filter == MediaFilter.ALL
    val selectedItems = (state.saved + state.rewind + state.statuses.values.flatten())
        .filter { it.uri in selected }
        .distinctBy { it.uri }

    // Back: close selection -> other tabs return to Statuses -> press twice to exit.
    BackHandler(enabled = selected.isNotEmpty()) { selected = emptySet() }
    BackHandler(enabled = selected.isEmpty() && preview == null) {
        if (tab != HomeTab.STATUSES) {
            tab = HomeTab.STATUSES
        } else {
            val now = SystemClock.elapsedRealtime()
            if (now - lastBack < 2000) {
                (context as? Activity)?.finish()
            } else {
                lastBack = now
                scope.launch { snackbar.showSnackbar(exitHint) }
            }
        }
    }

    fun toggle(item: StatusItem) {
        selected = if (item.uri in selected) selected - item.uri else selected + item.uri
    }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            topBar = {
                if (selected.isNotEmpty()) {
                    TopAppBar(
                        title = { Text(stringResource(R.string.selected_count, selected.size)) },
                        navigationIcon = {
                            IconButton(onClick = { selected = emptySet() }) {
                                Icon(Icons.Filled.Close, stringResource(R.string.cd_clear_selection))
                            }
                        },
                        actions = {
                            if (tab == HomeTab.STATUSES || tab == HomeTab.REWIND) {
                                IconButton(onClick = { vm.save(selectedItems); selected = emptySet() }) {
                                    Icon(Icons.Filled.Download, stringResource(R.string.cd_save_selected))
                                }
                            }
                            if (tab == HomeTab.SAVED || tab == HomeTab.REWIND) {
                                IconButton(onClick = {
                                    if (tab == HomeTab.REWIND) vm.deleteRewind(selectedItems) else vm.delete(selectedItems)
                                    selected = emptySet()
                                }) {
                                    Icon(Icons.Filled.Delete, stringResource(R.string.cd_delete_selected))
                                }
                            }
                        },
                    )
                } else {
                    TopAppBar(title = { Text(stringResource(R.string.app_name)) })
                }
            },
            bottomBar = {
                NavigationBar {
                    visibleTabs.forEach { t ->
                        NavigationBarItem(
                            selected = tab == t,
                            onClick = { tab = t; selected = emptySet() },
                            icon = { Icon(t.icon, contentDescription = null) },
                            label = { Text(stringResource(t.label)) },
                        )
                    }
                }
            },
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                when (tab) {
                    HomeTab.STATUSES -> {
                        if (state.feeds.isEmpty()) {
                            val scanning = !state.loaded || (state.refreshing && state.access.values.any { it })
                            if (scanning) {
                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator()
                                }
                            } else {
                                OnboardingScreen(access = state.access, onConnect = ::pick)
                            }
                        } else {
                            ScrollableTabRow(selectedTabIndex = feedIndex, edgePadding = 8.dp) {
                                state.feeds.forEach { feed ->
                                    Tab(
                                        selected = feed.key == state.selectedFeedKey,
                                        onClick = { vm.selectFeed(feed.key); selected = emptySet() },
                                        text = { Text(feedLabel(feed, state.nicknames)) },
                                    )
                                }
                            }
                            FilterRow(filter, baseItems) { filter = it; selected = emptySet() }
                            SwipePages(
                                resetKey = "statuses-$feedsMode",
                                pageCount = if (feedsMode) state.feeds.size else MediaFilter.entries.size,
                                currentPage = if (feedsMode) feedIndex else filter.ordinal,
                                onPageSettled = { p ->
                                    selected = emptySet()
                                    if (feedsMode) state.feeds.getOrNull(p)?.let { vm.selectFeed(it.key) }
                                    else filter = MediaFilter.entries[p]
                                },
                            ) { page ->
                                val list = remember(feedsMode, page, feedItems, state.feeds, state.statuses) {
                                    if (feedsMode) {
                                        state.feeds.getOrNull(page)?.let { state.statuses[it.key] }.orEmpty()
                                    } else {
                                        feedItems.applyFilter(MediaFilter.entries[page])
                                    }
                                }
                                Grid(list, state, selected, stringResource(R.string.empty_statuses), vm,
                                    onOpen = { i -> preview = PreviewRequest(list, i, PreviewSource.STATUS) },
                                    onToggle = ::toggle)
                            }
                        }
                    }
                    HomeTab.REWIND -> {
                        FilterRow(filter, baseItems) { filter = it; selected = emptySet() }
                        SwipePages(
                            resetKey = "rewind",
                            pageCount = MediaFilter.entries.size,
                            currentPage = filter.ordinal,
                            onPageSettled = { p -> selected = emptySet(); filter = MediaFilter.entries[p] },
                        ) { page ->
                            val list = remember(state.rewind, page) { state.rewind.applyFilter(MediaFilter.entries[page]) }
                            Grid(list, state, selected, stringResource(R.string.empty_rewind), vm,
                                showExpiry = true,
                                onOpen = { i -> preview = PreviewRequest(list, i, PreviewSource.REWIND) },
                                onToggle = ::toggle)
                        }
                    }
                    HomeTab.SAVED -> {
                        FilterRow(filter, baseItems) { filter = it; selected = emptySet() }
                        SwipePages(
                            resetKey = "saved",
                            pageCount = MediaFilter.entries.size,
                            currentPage = filter.ordinal,
                            onPageSettled = { p -> selected = emptySet(); filter = MediaFilter.entries[p] },
                        ) { page ->
                            val list = remember(state.saved, page) { state.saved.applyFilter(MediaFilter.entries[page]) }
                            Grid(list, state, selected, stringResource(R.string.empty_saved), vm,
                                onOpen = { i -> preview = PreviewRequest(list, i, PreviewSource.SAVED) },
                                onToggle = ::toggle)
                        }
                    }
                    HomeTab.SETTINGS -> SettingsScreen(
                        state = state,
                        onTheme = vm::setTheme,
                        onAutoSave = vm::setAutoSave,
                        onRewind = vm::setRewind,
                        onClearRewind = vm::clearRewind,
                        onConnect = ::pick,
                        onRename = vm::rename,
                    )
                    HomeTab.DONATE -> DonateScreen()
                }
            }
        }

        preview?.let { req ->
            BackHandler { preview = null }
            PreviewScreen(
                request = req,
                savedNames = state.savedNames,
                onClose = { preview = null },
                onSave = { vm.save(listOf(it)) },
                onShare = { item -> vm.share(item) { shareItem(context, it) } },
                onDelete = { item ->
                    if (req.source == PreviewSource.REWIND) vm.deleteRewind(listOf(item)) else vm.delete(listOf(item))
                    preview = null
                },
            )
        }

        SnackbarHost(
            hostState = snackbar,
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 88.dp),
        )
    }

    if (state.askBusiness) {
        AlertDialog(
            onDismissRequest = vm::answerBusinessPrompt,
            title = { Text(stringResource(R.string.business_prompt_title)) },
            text = { Text(stringResource(R.string.business_prompt_body)) },
            confirmButton = {
                TextButton(onClick = { vm.answerBusinessPrompt(); pick(WaApp.BUSINESS) }) {
                    Text(stringResource(R.string.btn_connect))
                }
            },
            dismissButton = {
                TextButton(onClick = vm::answerBusinessPrompt) { Text(stringResource(R.string.btn_not_now)) }
            },
        )
    }
}

@Composable
private fun Grid(
    items: List<StatusItem>,
    state: UiState,
    selected: Set<Uri>,
    emptyText: String,
    vm: MainViewModel,
    showExpiry: Boolean = false,
    onOpen: (Int) -> Unit,
    onToggle: (StatusItem) -> Unit,
) {
    MediaGrid(
        items = items,
        savedNames = state.savedNames,
        selected = selected,
        refreshing = state.refreshing,
        emptyText = emptyText,
        onRefresh = { vm.refresh(force = true) },
        onClick = { index, item -> if (selected.isNotEmpty()) onToggle(item) else onOpen(index) },
        onLongClick = onToggle,
        showExpiry = showExpiry,
    )
}
