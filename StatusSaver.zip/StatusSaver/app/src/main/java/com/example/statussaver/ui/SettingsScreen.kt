package com.example.statussaver.ui

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.statussaver.R
import com.example.statussaver.data.StatusFeed
import com.example.statussaver.data.ThemeMode
import com.example.statussaver.data.WaApp

@StringRes
private fun ThemeMode.labelRes(): Int = when (this) {
    ThemeMode.SYSTEM -> R.string.theme_system
    ThemeMode.LIGHT -> R.string.theme_light
    ThemeMode.DARK -> R.string.theme_dark
}

@Composable
private fun SectionTitle(@StringRes id: Int) {
    Text(
        stringResource(id),
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 16.dp, bottom = 4.dp),
    )
}

@Composable
fun SettingsScreen(
    state: UiState,
    onTheme: (ThemeMode) -> Unit,
    onAutoSave: (Boolean) -> Unit,
    onConnect: (WaApp) -> Unit,
    onRename: (String, String) -> Unit,
) {
    var renaming by remember { mutableStateOf<StatusFeed?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp)) {
        SectionTitle(R.string.settings_appearance)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ThemeMode.entries.forEach { mode ->
                FilterChip(
                    selected = state.themeMode == mode,
                    onClick = { onTheme(mode) },
                    label = { Text(stringResource(mode.labelRes())) },
                )
            }
        }

        HorizontalDivider(Modifier.padding(top = 16.dp))
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).padding(end = 12.dp)) {
                Text(stringResource(R.string.settings_autosave), style = MaterialTheme.typography.titleMedium)
                Text(
                    stringResource(R.string.settings_autosave_desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(checked = state.autoSave, onCheckedChange = onAutoSave)
        }
        HorizontalDivider()

        SectionTitle(R.string.settings_folders)
        WaApp.entries.forEach { app ->
            val connected = state.access[app] == true
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(app.label, style = MaterialTheme.typography.bodyLarge)
                    Text(
                        stringResource(if (connected) R.string.folder_connected else R.string.folder_not_connected),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                OutlinedButton(onClick = { onConnect(app) }) {
                    Text(stringResource(if (connected) R.string.btn_change else R.string.btn_connect))
                }
            }
        }

        if (state.feeds.isNotEmpty()) {
            SectionTitle(R.string.settings_accounts)
            Text(
                stringResource(R.string.settings_accounts_desc),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            state.feeds.forEach { feed ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(feedLabel(feed, state.nicknames), Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                    IconButton(onClick = { renaming = feed }) {
                        Icon(Icons.Filled.Edit, stringResource(R.string.cd_rename))
                    }
                }
            }
        }

        SectionTitle(R.string.settings_about)
        Text(
            stringResource(R.string.rights_notice),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }

    renaming?.let { feed ->
        var text by remember(feed.key) { mutableStateOf(state.nicknames[feed.key].orEmpty()) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text(stringResource(R.string.rename_title)) },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    label = { Text(feed.defaultLabel) },
                )
            },
            confirmButton = {
                TextButton(onClick = { onRename(feed.key, text); renaming = null }) {
                    Text(stringResource(android.R.string.ok))
                }
            },
            dismissButton = {
                TextButton(onClick = { renaming = null }) { Text(stringResource(android.R.string.cancel)) }
            },
        )
    }
}
