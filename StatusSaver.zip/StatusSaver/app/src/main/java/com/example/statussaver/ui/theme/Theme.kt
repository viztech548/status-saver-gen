package com.example.statussaver.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Palette taken from the app icon: deep navy, emerald and mint.
private val BrandDark = darkColorScheme(
    primary = Color(0xFF22D38A),
    onPrimary = Color(0xFF03261B),
    primaryContainer = Color(0xFF0F5C45),
    onPrimaryContainer = Color(0xFFBFFFE3),
    secondary = Color(0xFF7CE7BE),
    onSecondary = Color(0xFF03261B),
    secondaryContainer = Color(0xFF0F4A3F),
    onSecondaryContainer = Color(0xFFD6FFEE),
    tertiary = Color(0xFF8CFFCB),
    onTertiary = Color(0xFF03261B),
    background = Color(0xFF07142B),
    onBackground = Color(0xFFE6F4EE),
    surface = Color(0xFF07142B),
    onSurface = Color(0xFFE6F4EE),
    surfaceVariant = Color(0xFF12304A),
    onSurfaceVariant = Color(0xFFA9BDB8),
    surfaceContainerLowest = Color(0xFF050F20),
    surfaceContainerLow = Color(0xFF0A1A33),
    surfaceContainer = Color(0xFF0C2038),
    surfaceContainerHigh = Color(0xFF102842),
    surfaceContainerHighest = Color(0xFF14304D),
    outline = Color(0xFF4F7A76),
    outlineVariant = Color(0xFF223F57),
)

private val BrandLight = lightColorScheme(
    primary = Color(0xFF0F7A5C),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFBFF5DD),
    onPrimaryContainer = Color(0xFF00382A),
    secondary = Color(0xFF0B3B3A),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFC8F2E1),
    onSecondaryContainer = Color(0xFF07352A),
    tertiary = Color(0xFF0B3B3A),
    onTertiary = Color(0xFFFFFFFF),
    background = Color(0xFFF2FBF7),
    onBackground = Color(0xFF0A1B1A),
    surface = Color(0xFFF2FBF7),
    onSurface = Color(0xFF0A1B1A),
    surfaceVariant = Color(0xFFDDEBE5),
    onSurfaceVariant = Color(0xFF3E5650),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFEAF6F0),
    surfaceContainer = Color(0xFFE2F1EA),
    surfaceContainerHigh = Color(0xFFDAECE3),
    surfaceContainerHighest = Color(0xFFD2E7DD),
    outline = Color(0xFF6F8A83),
    outlineVariant = Color(0xFFBCD3CB),
)

@Composable
fun StatusSaverTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(colorScheme = if (darkTheme) BrandDark else BrandLight, content = content)
}
