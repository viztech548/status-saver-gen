package com.example.statussaver.data

import android.net.Uri
import androidx.compose.runtime.Immutable

// @Immutable tells Compose this never changes after creation, so it can skip redrawing unchanged cells.
@Immutable
data class StatusItem(
    val uri: Uri,
    val name: String,
    val mimeType: String,
    val modified: Long,
    val sizeBytes: Long = 0L,
) {
    val isVideo: Boolean get() = mimeType.startsWith("video/")

    /** Computed once, used as the stable id of the grid cell. */
    val key: String = uri.toString()
}
