package com.example.statussaver.data

import android.net.Uri

data class StatusItem(
    val uri: Uri,
    val name: String,
    val mimeType: String,
    val modified: Long,
    val sizeBytes: Long = 0L,
) {
    val isVideo: Boolean get() = mimeType.startsWith("video/")
}
