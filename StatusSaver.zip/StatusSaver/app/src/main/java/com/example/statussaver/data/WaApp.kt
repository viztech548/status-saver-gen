package com.example.statussaver.data

/** The two WhatsApp apps. rootPath is where the user is sent in the folder picker. */
enum class WaApp(val label: String, val rootPath: String) {
    WHATSAPP("WhatsApp", "Android/media/com.whatsapp/WhatsApp"),
    BUSINESS("WhatsApp Business", "Android/media/com.whatsapp.w4b/WhatsApp Business");

    val initialDocumentId: String get() = "primary:$rootPath"
}

enum class ThemeMode { SYSTEM, LIGHT, DARK }
