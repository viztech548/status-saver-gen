package com.example.statussaver.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier

/**
 * Horizontal pager kept in sync with state owned by the caller:
 * [currentPage] drives the pager (chip or tab taps), [onPageSettled] reports swipes.
 * Changing [resetKey] rebuilds the pager (used when the meaning of the pages changes).
 */
@Composable
fun SwipePages(
    resetKey: Any,
    pageCount: Int,
    currentPage: Int,
    onPageSettled: (Int) -> Unit,
    content: @Composable (page: Int) -> Unit,
) {
    key(resetKey) {
        val count = pageCount.coerceAtLeast(1)
        val pager = rememberPagerState(initialPage = currentPage.coerceIn(0, count - 1)) { count }
        val settled = rememberUpdatedState(onPageSettled)

        LaunchedEffect(currentPage) {
            if (currentPage in 0 until count && pager.currentPage != currentPage) {
                pager.animateScrollToPage(currentPage)
            }
        }
        LaunchedEffect(pager) {
            snapshotFlow { pager.settledPage }.collect { settled.value(it) }
        }
        HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page -> content(page) }
    }
}
