package com.example.statussaver.ui

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.statussaver.R
import com.example.statussaver.data.StatusItem

enum class MediaFilter(@StringRes val label: Int) {
    ALL(R.string.filter_all),
    IMAGES(R.string.filter_images),
    VIDEOS(R.string.filter_videos),
}

fun List<StatusItem>.applyFilter(filter: MediaFilter): List<StatusItem> = when (filter) {
    MediaFilter.ALL -> this
    MediaFilter.IMAGES -> filter { !it.isVideo }
    MediaFilter.VIDEOS -> filter { it.isVideo }
}

/** Chips with live counts: All (168) / Images (120) / Videos (48). */
@Composable
fun FilterRow(filter: MediaFilter, all: List<StatusItem>, onChange: (MediaFilter) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        MediaFilter.entries.forEach { f ->
            FilterChip(
                selected = filter == f,
                onClick = { onChange(f) },
                label = { Text("${stringResource(f.label)} (${all.applyFilter(f).size})") },
            )
        }
    }
}
