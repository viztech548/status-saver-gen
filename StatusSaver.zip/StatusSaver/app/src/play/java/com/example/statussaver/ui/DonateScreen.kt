package com.example.statussaver.ui

import androidx.compose.runtime.Composable

/** Google Play edition: intentionally empty. Donations outside Play Billing are not allowed on Play. */
@Composable
fun DonateScreen() {
}
