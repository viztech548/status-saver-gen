# Coil, Media3, WorkManager and Compose ship their own rules. These two are created by name at runtime.
-keep class com.example.statussaver.ui.MainViewModel { <init>(android.app.Application); }
-keep class com.example.statussaver.data.AutoSaveWorker { <init>(android.content.Context, androidx.work.WorkerParameters); }
