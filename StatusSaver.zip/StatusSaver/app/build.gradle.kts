plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.statussaver"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.umaa.status548"
        minSdk = 30
        targetSdk = 36          // Google Play requires API 36 for new apps since 2026-08-31
        versionCode = 5
        versionName = "1.4"
    }

    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
        // "direct" = APK you share yourself (GitHub). Same fixed key every time, so updates install over each other.
        create("direct") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
        // "upload" = key for the Google Play bundle. Never stored in the code: it comes from GitHub secrets.
        create("upload") {
            System.getenv("UPLOAD_KEYSTORE_PATH")?.let { path ->
                storeFile = file(path)
                storePassword = System.getenv("UPLOAD_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("UPLOAD_KEY_ALIAS")
                keyPassword = System.getenv("UPLOAD_KEY_PASSWORD")
            }
        }
    }

    flavorDimensions += "channel"
    productFlavors {
        // Direct APK: has the Support (donation) tab.
        create("direct") {
            dimension = "channel"
            buildConfigField("boolean", "DONATIONS_ENABLED", "true")
            signingConfig = signingConfigs.getByName("direct")
        }
        // Google Play: no donation code at all (Play payments policy).
        create("play") {
            dimension = "channel"
            buildConfigField("boolean", "DONATIONS_ENABLED", "false")
            signingConfig = signingConfigs.getByName("upload")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    lint { checkReleaseBuilds = false }
    bundle { language { enableSplit = false } } // keep English + French inside the bundle
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("io.coil-kt:coil-video:2.7.0")
    implementation("androidx.media3:media3-exoplayer:1.5.0")
    implementation("androidx.media3:media3-ui:1.5.0")
    implementation("androidx.work:work-runtime-ktx:2.10.0")
}
